#!/bin/bash
uso(){
    echo "Uso: $0 <origen> <destino>"
    echo "  origen  directorio a backupear (ej: /var/log)"
    echo "  destino directorio donde se guarda (ej: /backup_dir)" 
    echo "Opciones: -help, --help, -h  muestra esta ayuda"
}
case "$1" in -help|--help|-h) uso; exit 0 ;; esac
if [ $# -ne 2 ]; then echo "Error: Se reuieren 2 argumentos."; exit 1; fi
ORIGEN="${1%/}"
DESTINO="${2%/}"
if [ ! -d "$ORIGEN" ]; then echo "Error: origen '$ORIGEN' no disponible."; exit 2; fi
if [ ! -d "$DESTINO" ]; then echo "Error: destino '$DESTINO' no disponible."; exit 2; fi
if ! mountpoint -q "$DESTINO"; then echo "Error: '$DESTINO' no es un sistema de archivos montado."; exit 3; fi
FECHA=$(date +%Y%m%d)
NOMBRE=$(basename "$ORIGEN")
ARCHIVO="$DESTINO/${NOMBRE}_bkp_${FECHA}.tar.gz"
tar -czf "$ARCHIVO" -C "$(dirname "$ORIGEN")" "$NOMBRE" && echo "Backup creado: $ARCHIVO" || { echo "Error al crear el backup."; exit 4; }
