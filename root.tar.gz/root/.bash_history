history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
hostnamectl set-hostname TPServer
nano etc-hosts
loadkeys us
dpkg-reconfigure keyboard-configuration
dpkg-reconfigure keyboard-configuration
clear
dpkg-reconfigure keyboard-configuration
clear
H=$(hostname); hostnamectl set-hostname TPServer; hostname TPServer; sed -i "s/$H/TPServer/g" /etc/hosts; hostname; cat /etc/hosts
cat /etc/debian_version; ip a
ping -c 3 8.8.8.8
ping -c 3 deb.debian.org
apt update && apt full-upgrade -y
cat /etc/apt/sources.list
sed -i 's/bullseye/bookorn/g' /etc/apt/sources.list; cat /etc/apt/sources.list
apt update
ping -c 3 8.8.8.8
echo nameserver 8.8.8.8 | tee /etc/resolv.conf
ping -c 3 deb.debian.org
apt update
cat /etc/resolv.conf
grep -ri proxy /etc/apt/
getent hosts deb.debian.org
ping -c 3 deb.debian.org
apt update
echo deb http://deb.debian.org/debian bookworm main | tee /etc/apt/sources.list
echo deb http://deb.debian.org/debian-security bookworm-security main | tee -a /etc/apt/sources.list
echo deb hhtp://deb.debian.org/debian bookworm-updates main | tee -a /etc/apt/sources.list
cat /etc/apt/sources.list
ls /etc/apt/sources.list.d/
apt update
echo deb http://deb.debian.org/debian bookworm main | tee /etc/apt/sources.list
echo deb http://deb.debian.org/debian-security bookworm-security main | tee -a /etc/apt/sources.list
echo deb http://deb.debian.org/debian bookworm-updates main | tee -a /etc/apt/sources.list
cat /etc/apt/sources.list
apt update
apt upgrade --without-new-pkgs -y
apt full-upgrade -y
reboot
cat /etc/debian_version
ip a
apt install -y openssh-server nano
ssh-keygen -t rsa -b 4096 -f /root/.ssh/id_rsa -N ""
cat /root/.ssh/id_rsa.pub | tee -a /root/.ssh/authorized_keys
chmod 700 /root/.ssh; chmod 600 /root/.ssh/authorized_keys
nano /etc/ssh/sshd_conig
ls -l /etc/ssh
grep -E "PermitRootLogin|PubkeyAuthentication" /etc/ssh/sshd_config
nano /etc/ssh/sshd_config
grep -E "PermitRootLogin|PubkeyAuthentication" /etc/ssh/sshd_config
systemctl restart ssh; systemctl enable ssh; systemctl status ssh
sed -i 's/^#\?PermitRootLogin.*/PermitRootLogin yes/' /etc/ssh/sshd_config; systemctl restart ssh
grep PermitRootLogin /etc/ssh/sshd_config
sed -i 's/^#\?PermitRootLogin.*/PermitRootLogin prohibit-password/' /etc/ssh/sshd_config; systemctl restart ssh; grep PermitRootLogin /etc/ssh/sshd_config
apt install -y apache2 php libapache2-mod-php mariadb-server php-mysql nano
php -v | head -1; systemctl is-active apache2 mariadb
ls -l /root
tar -tzf /root/Material_Adicional_TPVMCA.tar.gz
tar -xzf /root/Material_Adicional_TPVMCA.tar.gz -C /root
ls -l /root
cp /root/Material_Adicional_TPVMCA/index.php /root/Material_Adicional_TPVMCA/logo.png /root/Material_Adicional_TPVMCA/db.sql /root/
ls -l /root
cat /root/Material_Adicional_TPVMCA/clave_publica.pub
cat /root/Material_Adicional_TPVMCA/clave_publica.pub | tee -a /root/.ssh/authorized_keys
chmod 600 /root/.ssh/authorized_keys; wc -l /root/.ssh/authorized_keys
mysql -u root < /root/db.sql
mysql -u root -e "SHOW DATABASES;"
grep -iE "mysqli|PDO|host|user|pass|dbname|database" /index.php
grep -iE "mysqli|PDO|host|user|pass|dbname|database" /root/index.php
mysql -u root -e "SELECT user,host FROM mysql.user;"
cp /root/index.php /root/logo.png /var/www/html/; rm -f /var/www/html/index.html; systemctl restart apache2
cp /etc/network/interfaces /etc/network/interfaces.bak
cat > /etc/network/interfaces <<'EOF'
source /etc/network.interfaces.d/*

auto lo
iface lo inet loopback

auto enp0s3
iface enp0s3 inet static
    address 192.168.1.200
    netmask 255.255.255.0
    gateway 192.168.1.1
    dns-nameservers 8.8.8.8
EOF

cat /etc/network/interfaces
reboot
lsblk
fdisk /dev/sdc
lsblk /dev/sdc
mkfs.ext4 /dev/sdc1; mkfs.ext4 /dev/sdc2
mkdir -p /www_dir /backup_dir; mount /dev/sdc1 /www_dir; mount/dev/sdc2 backup_dir; df -h | grep -E "www_dir|backup_dir"
mount /dev/sdc2 /backup_dir; df -h | grep -E "www_dir|backup_dir"
cp /root/index.php /root/logo.png /www_dir/
sed -i 's#DocumentRoot /var/www/html#DocuentRoot /www_dir#' /etc/apache2/sites-available/000-default.conf
cat > /etc/apache2/conf-available/www_dir.conf << 'EOF'
<Directory /www_dir/>
  Options Indexes FollowSymLinks
  AllowOverride None
  Require all granted
</Directory>
EOF

a2enconf www_dir; apache2ctl configtest; systemctl restart apache2
sed -i 's#DocuentRoot#DocumentRoot#' /etc/apache2/sites-available/000-default.conf
grep DocumentRoot /etc/apache2/sites-available/000-default.conf
apache2ctl configtest; systemctl restart apache2; systemctl is-active apache2
ls -l /www_dir
blkid /dev/sdc1 /dev/sdc2
cat /proc/partitions > /opt/particion; cat /opt/particion
echo "UUID=0019449b-3e21-aeba-6e51aa8597de /www_dir ext4 defaults 0 2" >> /etc/fstab
echo "UUID=0019449b-3e21-444f-aeba-6e51aa88597de /www_dir ext4 defaults 0 2" >> /etc/fstab
echo "UUID=d582b388-d2f3-41d8-9f97-f29a5c7c52a6 /www_dir ext4 defaults 0 2" >> /etc/fstab
echo "UUID=0019449b-3e21-444f-aeba-6e51aa8597de /www_dir ext4 defaults 0 2" >> /etc/fstab
echo "UUID=d582b388-d2f3-41d8-9f97-f29a5c7c52a6 /backup_dir ext4 defaults 0 2" >> /etc/fstab
unmount /www_dir /backup_dir; mount -a; df -h | grep -E "www_dir|backup_dir"
sed -i '/www_dir/d;/backup_dir/d' /etc/fstab
echo "UUID=$(blkid -s UUID -o value /dev/sdc1) /www_dir ext4 defaults 0 2" >> /etc/fstab
echo "UUID=$(blkid -s UUID -o value /dev/sdc2) /backup_dir ext4 defaults 0 2" >> /etc/fstab
cat /etc/fstab
systemctl daemon-reload; reboot
